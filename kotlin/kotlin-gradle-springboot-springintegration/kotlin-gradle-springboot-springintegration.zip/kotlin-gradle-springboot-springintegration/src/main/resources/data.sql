INSERT INTO TRADE (
trade_id,type,sub_type,pnl_spn,spn,trade_date,price,quantity
) VALUES (
  'TE123',
  'Equity',
  'Common Stock',
  1234,
  123,
  '20210210',
  45.80,
  10
);